// first run this in terminal 
// npm install basic-calculator-js
// remove this 3 lines before showing

const calculate = require("basic-calculator-js")
 
var x = 50
var y = 50
 
console.log(calculate.multiply(50, 50));
console.log(calculate.subtract(x, y));
console.log(calculate.add(x,y));
console.log(calculate.divide(x, y));