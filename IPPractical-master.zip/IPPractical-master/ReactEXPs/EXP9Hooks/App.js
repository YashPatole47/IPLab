// import logo from './logo.svg';
import './App.css';
import Hooks1 from './Hooks1';

function App() {
  return (
    <div>
      <Hooks1 />
    </div>
  );
}

export default App;
