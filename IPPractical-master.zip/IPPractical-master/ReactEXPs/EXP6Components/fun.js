import React from 'react';

function fun() {
    return (
      <div className="fun">
        <h1>This is Function Component in React</h1>
        <ul>
            <li>This is Sample Unordered List Inside New Function </li>
            
        </ul>
      </div>
    );
  }
  
  export default fun;