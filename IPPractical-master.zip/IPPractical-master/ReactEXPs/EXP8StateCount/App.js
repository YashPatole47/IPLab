// import logo from './logo.svg';
import './App.css';
import StateCount from './StateCount';

function App() {
  return (
    <div>
      <StateCount />
    </div>
  );
}

export default App;
