// import logo from './logo.svg';
import './App.css';
import Props1 from './Props1';
import State1 from './State1';

function App() {
  return (
    <div>
      <Props1 name="Ayush" />
      <Props1 name="Prajwal" />
      <Props1 name="Manaswi" />
      <State1 />
    </div>
  );
}

export default App;
