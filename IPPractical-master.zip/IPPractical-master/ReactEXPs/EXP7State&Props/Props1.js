import React from "react";

function Props1(props) {
    return <h1>Hello, {props.name}</h1>;
}

export default Props1;
  